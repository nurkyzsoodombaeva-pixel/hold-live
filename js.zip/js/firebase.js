// firebase.js

import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import {
  getFirestore,
  collection,
  addDoc,
  onSnapshot,
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyA-fDNcAiaA_x4NPmkeCxA5CJxfxkNy_wE",
  authDomain: "hold-live.firebaseapp.com",
  projectId: "hold-live",
  storageBucket: "hold-live.firebasestorage.app",
  messagingSenderId: "174385633412",
  appId: "1:174385633412:web:589cca1940c411f9cc8ad1",
  measurementId: "G-3YLYRH53P0",
};

const app = initializeApp(firebaseConfig);

const db = getFirestore(app);

const productsCollection = collection(db, "products");

// Автоматическое получение товаров
export function fetchProducts(callback) {
  return onSnapshot(productsCollection, (snapshot) => {
    const products = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));

    callback(products);
  });
}

// Добавление товара
export async function saveProduct(product) {
  await addDoc(productsCollection, product);
}